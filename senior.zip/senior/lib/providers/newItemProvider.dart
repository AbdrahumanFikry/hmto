import 'package:flutter/material.dart';
import 'package:senior/models/newItem.dart';

class NewItemProvider with ChangeNotifier {
  NewItem newItem;
}
