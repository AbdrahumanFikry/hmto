import 'package:flutter/material.dart';

class GPS with ChangeNotifier {
  bool locationOn = false;
}
