import 'package:flutter/material.dart';

class DriverData with ChangeNotifier {}
